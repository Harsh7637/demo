package com.cg.films.frontend.dto;

public class CategoryDTO_MF {
    private Long categoryId;
    private String name;

    public CategoryDTO_MF() {
    }

    public CategoryDTO_MF(Long categoryId, String name) {
        this.categoryId = categoryId;
        this.name = name;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
