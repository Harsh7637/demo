package com.cg.films.frontend.controller;

import com.cg.films.frontend.dto.FilmDTO_MF;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import java.util.Comparator;
import java.util.List;

@Controller
public class FilmController_MF {

    private final RestTemplate restTemplate;

    @Value("${backend.api.url}")
    private String backendApiUrl;

    public FilmController_MF(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping("/mufi/films/category/{categoryName}")
    public String getFilmsByCategory(
            @PathVariable String categoryName,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String sortBy,
            @RequestParam(defaultValue = "asc") String sortOrder,
            Model model) {

        try {
            String url = backendApiUrl + "/films/category/" + categoryName;

            ResponseEntity<List<FilmDTO_MF>> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<FilmDTO_MF>>() {}
            );

            List<FilmDTO_MF> allFilms = response.getBody();

            if (allFilms != null && !allFilms.isEmpty()) {

                // ✅ Apply sorting
                if (sortBy != null && !sortBy.isEmpty()) {
                    allFilms = sortFilms(allFilms, sortBy, sortOrder);
                }

                // ✅ Pagination
                int totalFilms = allFilms.size();
                int totalPages = (int) Math.ceil((double) totalFilms / size);

                if (page < 1) page = 1;
                if (page > totalPages && totalPages > 0) page = totalPages;

                int startIndex = (page - 1) * size;
                int endIndex = Math.min(startIndex + size, totalFilms);

                List<FilmDTO_MF> paginatedFilms = allFilms.subList(startIndex, endIndex);

                model.addAttribute("films", paginatedFilms);
                model.addAttribute("categoryName", categoryName);
                model.addAttribute("currentPage", page);
                model.addAttribute("totalPages", totalPages);
                model.addAttribute("pageSize", size);
                model.addAttribute("totalFilms", totalFilms);
                model.addAttribute("sortBy", sortBy);
                model.addAttribute("sortOrder", sortOrder);

            } else {
                model.addAttribute("message", "No films found for category: " + categoryName);
            }

        } catch (Exception e) {
            model.addAttribute("error", "Failed to fetch films: " + e.getMessage());
        }

        return "films_MF";
    }

    // ✅ Type-safe sorting logic
    private List<FilmDTO_MF> sortFilms(List<FilmDTO_MF> films, String sortBy, String sortOrder) {
        Comparator<FilmDTO_MF> comparator;

        switch (sortBy.toLowerCase()) {
            case "filmid":
                comparator = Comparator.comparing(FilmDTO_MF::getFilmId,
                        Comparator.nullsLast(Long::compareTo));
                break;

            case "title":
                comparator = Comparator.comparing(
                        f -> f.getTitle() == null ? "" : f.getTitle().toLowerCase(),
                        String::compareTo);
                break;

            case "releaseyear":
                comparator = Comparator.comparing(FilmDTO_MF::getReleaseYear,
                        Comparator.nullsLast(Integer::compareTo));
                break;

            case "length":
                comparator = Comparator.comparing(FilmDTO_MF::getLength,
                        Comparator.nullsLast(Integer::compareTo));
                break;

            case "rating":
                comparator = Comparator.comparing(
                        f -> f.getRating() == null ? "" : f.getRating().toLowerCase(),
                        String::compareTo);
                break;

            default:
                comparator = Comparator.comparing(FilmDTO_MF::getFilmId,
                        Comparator.nullsLast(Long::compareTo));
        }

        if ("desc".equalsIgnoreCase(sortOrder)) {
            comparator = comparator.reversed();
        }

        films.sort(comparator);
        return films;
    }
}
