package com.cg.films.frontend.controller;

import com.cg.films.frontend.dto.CategoryDTO_MF;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.stream.Collectors;

@Controller
public class CategoryController_MF {

    private final RestTemplate restTemplate;

    @Value("${backend.api.url}")
    private String backendApiUrl;

    public CategoryController_MF(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping("/mufi/categories")
    public String getCategories(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String search,
            Model model) {

        try {
            String url = backendApiUrl + "/categories";
            ResponseEntity<List<CategoryDTO_MF>> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<CategoryDTO_MF>>() {}
            );

            List<CategoryDTO_MF> allCategories = response.getBody();

            if (allCategories != null) {

                // ✅ Apply search filter if provided
                if (search != null && !search.trim().isEmpty()) {
                    allCategories = allCategories.stream()
                            .filter(c -> c.getName() != null &&
                                    c.getName().toLowerCase().contains(search.toLowerCase()))
                            .collect(Collectors.toList());
                }

                // ✅ Pagination
                int totalCategories = allCategories.size();
                int totalPages = (int) Math.ceil((double) totalCategories / size);

                if (page < 1) page = 1;
                if (page > totalPages && totalPages > 0) page = totalPages;

                int startIndex = (page - 1) * size;
                int endIndex = Math.min(startIndex + size, totalCategories);

                List<CategoryDTO_MF> paginatedCategories = allCategories.subList(startIndex, endIndex);

                model.addAttribute("categories", paginatedCategories);
                model.addAttribute("currentPage", page);
                model.addAttribute("totalPages", totalPages);
                model.addAttribute("pageSize", size);
                model.addAttribute("totalCategories", totalCategories);
                model.addAttribute("search", search);
            }

        } catch (Exception e) {
            model.addAttribute("error", "Failed to fetch categories: " + e.getMessage());
        }

        return "categories_MF";
    }
}
