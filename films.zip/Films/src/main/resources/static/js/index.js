// Landing Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    console.log('🎬 Film Management System Loaded');

    // Smooth scroll for scroll indicator
    const scrollIndicator = document.querySelector('.scroll-indicator');
    if (scrollIndicator) {
        scrollIndicator.addEventListener('click', function() {
            document.querySelector('.team-section').scrollIntoView({ 
                behavior: 'smooth' 
            });
        });
    }

    // Add stagger animation to team cards
    const teamCards = document.querySelectorAll('.team-card');
    teamCards.forEach((card, index) => {
        card.style.animation = `zoomIn 0.6s ease-out ${index * 0.1}s both`;
    });

    // Parallax effect for background orbs
    document.addEventListener('mousemove', function(e) {
        const orbs = document.querySelectorAll('.gradient-orb');
        const mouseX = e.clientX / window.innerWidth;
        const mouseY = e.clientY / window.innerHeight;
        
        orbs.forEach((orb, index) => {
            const speed = (index + 1) * 20;
            const x = (mouseX - 0.5) * speed;
            const y = (mouseY - 0.5) * speed;
            
            orb.style.transform = `translate(${x}px, ${y}px)`;
        });
    });

    // Add ripple effect on card click
    teamCards.forEach(card => {
        if (!card.classList.contains('placeholder-card')) {
            card.addEventListener('click', function(e) {
                // Create ripple
                const ripple = document.createElement('div');
                ripple.className = 'ripple-effect';
                
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                ripple.style.left = x + 'px';
                ripple.style.top = y + 'px';
                
                card.appendChild(ripple);
                
                setTimeout(() => ripple.remove(), 600);
            });
        }
    });

    // Typing effect for hero subtitle
    const heroSubtitle = document.querySelector('.hero-subtitle');
    if (heroSubtitle) {
        const text = heroSubtitle.textContent;
        heroSubtitle.textContent = '';
        heroSubtitle.style.opacity = '1';
        
        let index = 0;
        function type() {
            if (index < text.length) {
                heroSubtitle.textContent += text.charAt(index);
                index++;
                setTimeout(type, 50);
            }
        }
        
        setTimeout(type, 1000);
    }

    // Add hover sound effect simulation (visual feedback)
    teamCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            if (!this.classList.contains('placeholder-card')) {
                this.style.boxShadow = '0 20px 60px rgba(139, 127, 255, 0.4)';
            }
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.boxShadow = '';
        });
    });

    // Intersection Observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe team cards
    teamCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });

    // Add keyboard navigation
    document.addEventListener('keydown', function(e) {
        // Press 'H' to go to home (refresh)
        if (e.key === 'h' || e.key === 'H') {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
        
        // Press 'T' to scroll to team
        if (e.key === 't' || e.key === 'T') {
            document.querySelector('.team-section').scrollIntoView({ 
                behavior: 'smooth' 
            });
        }
    });

    // Dynamic gradient animation for main title
    const gradientText = document.querySelector('.gradient-text');
    if (gradientText) {
        let hue = 270; // Starting hue for purple
        setInterval(() => {
            hue = (hue + 1) % 360;
            const color1 = `hsl(${hue}, 70%, 70%)`;
            const color2 = `hsl(${(hue + 60) % 360}, 70%, 75%)`;
            gradientText.style.background = `linear-gradient(135deg, ${color1}, ${color2})`;
            gradientText.style.webkitBackgroundClip = 'text';
            gradientText.style.backgroundClip = 'text';
        }, 50);
    }

    // Performance optimization: Debounce mouse move
    let mouseMoveTimeout;
    document.addEventListener('mousemove', function(e) {
        clearTimeout(mouseMoveTimeout);
        mouseMoveTimeout = setTimeout(() => {
            // Mouse move effects here
        }, 10);
    });
});

// Add ripple effect CSS dynamically
const style = document.createElement('style');
style.textContent = `
    .ripple-effect {
        position: absolute;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: rgba(139, 127, 255, 0.5);
        transform: translate(-50%, -50%) scale(0);
        animation: ripple 0.6s ease-out;
        pointer-events: none;
        z-index: 10;
    }
    
    @keyframes ripple {
        to {
            transform: translate(-50%, -50%) scale(20);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);