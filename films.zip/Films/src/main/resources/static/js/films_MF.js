// Films Page JavaScript with Sorting Functionality

document.addEventListener('DOMContentLoaded', function() {
    console.log('🎬 Films Page Loaded');

    // Get current URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const currentSort = urlParams.get('sortBy');
    const currentOrder = urlParams.get('sortOrder') || 'asc';
    const categoryName = window.location.pathname.split('/').pop();

    // Handle column sorting
    const sortableHeaders = document.querySelectorAll('.sortable');
    
    sortableHeaders.forEach(header => {
        const sortField = header.getAttribute('data-sort');
        const sortIcon = header.querySelector('.sort-icon');
        
        // Update icon based on current sort
        if (sortField === currentSort) {
            if (currentOrder === 'asc') {
                sortIcon.classList.remove('fa-sort');
                sortIcon.classList.add('fa-sort-up');
            } else {
                sortIcon.classList.remove('fa-sort');
                sortIcon.classList.add('fa-sort-down');
            }
            header.style.background = 'rgba(255, 255, 255, 0.2)';
            header.style.fontWeight = '800';
        }
        
        // Add click event for sorting
        header.addEventListener('click', function() {
            let newOrder = 'asc';
            
            // Toggle order if clicking the same column
            if (sortField === currentSort) {
                newOrder = currentOrder === 'asc' ? 'desc' : 'asc';
            }
            
            // Build new URL with sort parameters
            const currentPage = urlParams.get('page') || '1';
            const pageSize = urlParams.get('size') || '10';
            
            const newUrl = `/mufi/films/category/${categoryName}?page=${currentPage}&size=${pageSize}&sortBy=${sortField}&sortOrder=${newOrder}`;
            
            // Add loading animation
            const table = document.querySelector('.films-table');
            if (table) {
                table.style.opacity = '0.5';
                table.style.transform = 'scale(0.98)';
                table.style.transition = 'all 0.3s ease';
            }
            
            // Show loading indicator
            const tableContainer = document.querySelector('.table-container');
            const loader = document.createElement('div');
            loader.className = 'table-loader';
            loader.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sorting...';
            tableContainer.appendChild(loader);
            
            // Navigate with smooth transition
            setTimeout(() => {
                window.location.href = newUrl;
            }, 300);
        });
        
        // Enhanced hover effect for sortable headers
        header.addEventListener('mouseenter', function() {
            this.style.background = 'rgba(255, 255, 255, 0.15)';
            this.style.transform = 'scale(1.02)';
            this.style.transition = 'all 0.3s ease';
            
            const icon = this.querySelector('.sort-icon');
            if (icon) {
                icon.style.transform = 'scale(1.3)';
                icon.style.transition = 'transform 0.3s ease';
            }
        });
        
        header.addEventListener('mouseleave', function() {
            if (sortField !== currentSort) {
                this.style.background = '';
            }
            this.style.transform = 'scale(1)';
            
            const icon = this.querySelector('.sort-icon');
            if (icon) {
                icon.style.transform = 'scale(1)';
            }
        });
    });

    // Animate film rows on load
    const filmRows = document.querySelectorAll('.film-row');
    filmRows.forEach((row, index) => {
        row.style.opacity = '0';
        row.style.transform = 'translateX(-30px)';
        
        setTimeout(() => {
            row.style.transition = 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
            row.style.opacity = '1';
            row.style.transform = 'translateX(0)';
        }, index * 60);
    });

    // Enhanced hover effect for film rows
    filmRows.forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
            
            // Slightly fade adjacent rows
            const prevRow = this.previousElementSibling;
            const nextRow = this.nextElementSibling;
            
            if (prevRow && prevRow.classList.contains('film-row')) {
                prevRow.style.opacity = '0.6';
            }
            if (nextRow && nextRow.classList.contains('film-row')) {
                nextRow.style.opacity = '0.6';
            }
        });
        
        row.addEventListener('mouseleave', function() {
            const prevRow = this.previousElementSibling;
            const nextRow = this.nextElementSibling;
            
            if (prevRow && prevRow.classList.contains('film-row')) {
                prevRow.style.opacity = '1';
            }
            if (nextRow && nextRow.classList.contains('film-row')) {
                nextRow.style.opacity = '1';
            }
        });
    });

    // Parallax effect for background shapes
    let ticking = false;
    document.addEventListener('mousemove', function(e) {
        if (!ticking) {
            window.requestAnimationFrame(function() {
                const shapes = document.querySelectorAll('.shape');
                const mouseX = e.clientX / window.innerWidth;
                const mouseY = e.clientY / window.innerHeight;
                
                shapes.forEach((shape, index) => {
                    const speed = (index + 1) * 18;
                    const x = (mouseX - 0.5) * speed;
                    const y = (mouseY - 0.5) * speed;
                    
                    shape.style.transform = `translate(${x}px, ${y}px)`;
                });
                
                ticking = false;
            });
            ticking = true;
        }
    });

    // Smooth scroll for pagination with loading effect
    const paginationLinks = document.querySelectorAll('.page-link');
    paginationLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // Smooth scroll to top
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
            
            // Add page transition effect
            const tableContainer = document.querySelector('.table-container');
            if (tableContainer) {
                tableContainer.style.opacity = '0.6';
                tableContainer.style.transform = 'scale(0.98)';
                tableContainer.style.transition = 'all 0.3s ease';
            }
        });
    });

    // Click to copy film title functionality
    const filmTitles = document.querySelectorAll('.film-title');
    filmTitles.forEach(title => {
        title.style.cursor = 'pointer';
        title.title = 'Click to copy title';
        
        title.addEventListener('click', function(e) {
            e.stopPropagation();
            const text = this.textContent;
            
            // Copy to clipboard
            navigator.clipboard.writeText(text).then(() => {
                // Show success tooltip
                const tooltip = document.createElement('div');
                tooltip.textContent = '✓ Copied!';
                tooltip.className = 'copy-tooltip';
                tooltip.style.cssText = `
                    position: fixed;
                    left: ${e.clientX}px;
                    top: ${e.clientY - 40}px;
                    background: linear-gradient(135deg, var(--primary), var(--secondary));
                    color: white;
                    padding: 0.75rem 1.5rem;
                    border-radius: 12px;
                    font-size: 0.95rem;
                    font-weight: 700;
                    z-index: 10000;
                    box-shadow: 0 4px 16px rgba(139, 127, 255, 0.4);
                    animation: tooltipFade 2s ease-out forwards;
                    pointer-events: none;
                `;
                document.body.appendChild(tooltip);
                
                // Pulse animation on title
                this.style.transform = 'scale(1.05)';
                this.style.color = 'var(--primary)';
                setTimeout(() => {
                    this.style.transform = 'scale(1)';
                    this.style.color = '';
                }, 200);
                
                setTimeout(() => tooltip.remove(), 2000);
            }).catch(err => {
                console.error('Failed to copy:', err);
            });
        });
    });

    // Enhanced badge hover effects
    const badges = document.querySelectorAll('.badge-pill');
    badges.forEach(badge => {
        badge.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px) scale(1.08) rotate(2deg)';
        });
        
        badge.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1) rotate(0deg)';
        });
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Press 'B' or ESC to go back
        if (e.key === 'b' || e.key === 'B' || e.key === 'Escape') {
            const backBtn = document.querySelector('.back-btn');
            if (backBtn) backBtn.click();
        }
        
        // Arrow keys for pagination
        if (e.key === 'ArrowLeft') {
            const prevBtn = document.querySelector('.page-item:not(.disabled) .page-link i.fa-chevron-left');
            if (prevBtn) prevBtn.closest('a').click();
        }
        
        if (e.key === 'ArrowRight') {
            const nextBtn = document.querySelector('.page-item:not(.disabled) .page-link i.fa-chevron-right');
            if (nextBtn) nextBtn.closest('a').click();
        }
    });

    // Table scroll indicator for mobile
    const tableResponsive = document.querySelector('.table-responsive');
    if (tableResponsive) {
        const table = tableResponsive.querySelector('table');
        
        if (table.offsetWidth > tableResponsive.offsetWidth) {
            // Add scroll indicator
            const indicator = document.createElement('div');
            indicator.className = 'scroll-indicator-bar';
            indicator.innerHTML = '<i class="fas fa-arrows-alt-h"></i> Scroll horizontally';
            indicator.style.cssText = `
                text-align: center;
                padding: 1rem;
                color: var(--text-secondary);
                font-size: 0.9rem;
                background: linear-gradient(135deg, rgba(139, 127, 255, 0.1), rgba(255, 180, 214, 0.1));
                border-radius: 12px;
                margin-bottom: 1rem;
                animation: pulse 2s ease-in-out infinite;
            `;
            tableResponsive.parentElement.insertBefore(indicator, tableResponsive);
            
            // Remove indicator after first scroll
            tableResponsive.addEventListener('scroll', function() {
                if (this.scrollLeft > 20) {
                    indicator.style.display = 'none';
                }
            }, { once: true });
        }
    }

    // Log page statistics
    console.log('✅ Films page fully loaded');
    console.log(`📊 Total films displayed: ${filmRows.length}`);
    console.log(`🔄 Current sort: ${currentSort || 'none'} (${currentOrder})`);
});

// Dynamic CSS for animations
const style = document.createElement('style');
style.textContent = `
    @keyframes tooltipFade {
        0% { 
            opacity: 0; 
            transform: translateY(10px); 
        }
        20% { 
            opacity: 1; 
            transform: translateY(0); 
        }
        80% { 
            opacity: 1; 
        }
        100% { 
            opacity: 0; 
            transform: translateY(-20px); 
        }
    }
    
    .table-loader {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        font-size: 1.5rem;
        color: var(--primary);
        font-weight: 700;
        z-index: 1000;
        display: flex;
        align-items: center;
        gap: 1rem;
        background: var(--bg-secondary);
        padding: 1.5rem 2.5rem;
        border-radius: 16px;
        box-shadow: 0 8px 32px var(--shadow);
        animation: fadeIn 0.3s ease;
    }
    
    .film-title {
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .badge-pill {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translate(-50%, -50%) scale(0.9); }
        to { opacity: 1; transform: translate(-50%, -50%) scale(1); }
    }
`;
document.head.appendChild(style);