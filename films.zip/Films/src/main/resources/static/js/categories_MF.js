// Categories Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    console.log('📂 Categories Page Loaded');

    // Stagger animation for category cards
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.08}s`;
    });

    // Enhanced search input interactions
    const searchInput = document.querySelector('.search-input');
    const searchWrapper = document.querySelector('.search-wrapper');
    
    if (searchInput) {
        // Focus effect
        searchInput.addEventListener('focus', function() {
            searchWrapper.style.transform = 'scale(1.02)';
            searchWrapper.style.transition = 'transform 0.3s ease';
        });
        
        searchInput.addEventListener('blur', function() {
            searchWrapper.style.transform = 'scale(1)';
        });

        // Real-time character count feedback
        searchInput.addEventListener('input', function() {
            if (this.value.length > 0) {
                this.style.fontWeight = '600';
                this.style.color = 'var(--primary)';
            } else {
                this.style.fontWeight = '400';
                this.style.color = 'var(--text-primary)';
            }
        });

        // Auto-focus on '/' key
        document.addEventListener('keydown', function(e) {
            if (e.key === '/' && document.activeElement !== searchInput) {
                e.preventDefault();
                searchInput.focus();
            }
            
            // ESC to clear and blur
            if (e.key === 'Escape' && document.activeElement === searchInput) {
                searchInput.value = '';
                searchInput.blur();
            }
        });
    }

    // Add click ripple effect to category cards
    categoryCards.forEach(card => {
        const categoryLink = card.querySelector('.category-link');
        
        categoryLink.addEventListener('click', function(e) {
            // Create ripple element
            const ripple = document.createElement('div');
            ripple.className = 'click-ripple';
            
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            
            card.appendChild(ripple);
            
            // Add loading state
            const categoryInner = card.querySelector('.category-inner');
            categoryInner.style.opacity = '0.7';
            categoryInner.style.transform = 'scale(0.98)';
            
            // Show loading indicator
            const loader = document.createElement('div');
            loader.className = 'loading-indicator';
            loader.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            card.appendChild(loader);
            
            setTimeout(() => ripple.remove(), 600);
        });
    });

    // Parallax effect for background shapes
    let ticking = false;
    document.addEventListener('mousemove', function(e) {
        if (!ticking) {
            window.requestAnimationFrame(function() {
                const shapes = document.querySelectorAll('.shape');
                const mouseX = e.clientX / window.innerWidth;
                const mouseY = e.clientY / window.innerHeight;
                
                shapes.forEach((shape, index) => {
                    const speed = (index + 1) * 15;
                    const x = (mouseX - 0.5) * speed;
                    const y = (mouseY - 0.5) * speed;
                    
                    shape.style.transform = `translate(${x}px, ${y}px)`;
                });
                
                ticking = false;
            });
            ticking = true;
        }
    });

    // Smooth scroll to top on pagination
    const paginationLinks = document.querySelectorAll('.page-link');
    paginationLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
            
            // Add loading animation to page
            document.body.style.opacity = '0.8';
            setTimeout(() => {
                document.body.style.opacity = '1';
            }, 300);
        });
    });

    // Enhanced hover effects for category cards
    categoryCards.forEach(card => {
        const categoryIconWrapper = card.querySelector('.category-icon-wrapper');
        const arrowIcon = card.querySelector('.arrow-icon');
        
        card.addEventListener('mouseenter', function() {
            // Icon animation
            if (categoryIconWrapper) {
                categoryIconWrapper.style.transform = 'rotate(10deg) scale(1.1)';
            }
            
            // Arrow animation
            if (arrowIcon) {
                arrowIcon.style.transform = 'translateX(8px)';
            }
        });
        
        card.addEventListener('mouseleave', function() {
            if (categoryIconWrapper) {
                categoryIconWrapper.style.transform = 'rotate(0deg) scale(1)';
            }
            
            if (arrowIcon) {
                arrowIcon.style.transform = 'translateX(0)';
            }
        });
    });

    // Stat cards animation on scroll
    const statCards = document.querySelectorAll('.stat-card');
    const observerOptions = {
        threshold: 0.5
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animation = 'slideIn 0.6s ease-out';
            }
        });
    }, observerOptions);
    
    statCards.forEach(card => observer.observe(card));

    // Add tooltip for category names
    const categoryNames = document.querySelectorAll('.category-name');
    categoryNames.forEach(name => {
        name.addEventListener('mouseenter', function() {
            this.style.color = 'var(--primary)';
            this.style.transition = 'color 0.3s ease';
        });
        
        name.addEventListener('mouseleave', function() {
            this.style.color = 'var(--text-primary)';
        });
    });

    // Performance monitoring
    console.log('✅ All animations and interactions loaded');
    console.log(`📊 Total categories on page: ${categoryCards.length}`);
});

// Dynamic CSS for ripple and loader
const style = document.createElement('style');
style.textContent = `
    .click-ripple {
        position: absolute;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: rgba(139, 127, 255, 0.6);
        transform: translate(-50%, -50%) scale(0);
        animation: rippleEffect 0.6s ease-out;
        pointer-events: none;
        z-index: 10;
    }
    
    @keyframes rippleEffect {
        to {
            transform: translate(-50%, -50%) scale(25);
            opacity: 0;
        }
    }
    
    .loading-indicator {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        font-size: 2.5rem;
        color: var(--primary);
        z-index: 100;
        animation: fadeIn 0.3s ease;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    
    .category-card {
        position: relative;
        overflow: hidden;
    }
    
    .category-icon-wrapper,
    .arrow-icon {
        transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    }
`;
document.head.appendChild(style);