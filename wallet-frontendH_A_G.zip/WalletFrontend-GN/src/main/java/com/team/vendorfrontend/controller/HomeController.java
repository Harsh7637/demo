package com.team.vendorfrontend.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Arrays;
import java.util.List;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home(Model model) {
        List<TeamMember> teamMembers = Arrays.asList(
            new TeamMember("Harsh", "Backend API Integration & Vendor Management", "/vendors_HR"),
            new TeamMember("Abdullah", "User Management & Payment Processing", "/users_AB"),
            new TeamMember("Ganesh", "Branch Management & Vendor Analytics", "/vendors_GN"),
            new TeamMember("Priya", "Authentication & Security Systems", "/auth_PY"),
            new TeamMember("Rahul", "Database Design & Optimization", "/database_RL"),
            new TeamMember("Sneha", "Order Management & Tracking", "/orders_SN"),
            new TeamMember("Amit", "Inventory Management System", "/inventory_AM"),
            new TeamMember("Kavya", "UI/UX Design & Frontend Development", "/design_KV")
        );

        model.addAttribute("teamMembers", teamMembers);
        model.addAttribute("projectName", "VendorFlow");
        model.addAttribute("projectTagline", "Next-Gen Vendor Management System");

        return "index";
    }

    // Inner class for team member data
    public static class TeamMember {
        private String name;
        private String contribution;
        private String link;

        public TeamMember(String name, String contribution, String link) {
            this.name = name;
            this.contribution = contribution;
            this.link = link;
        }

        public String getName() { return name; }
        public String getContribution() { return contribution; }
        public String getLink() { return link; }
    }
}