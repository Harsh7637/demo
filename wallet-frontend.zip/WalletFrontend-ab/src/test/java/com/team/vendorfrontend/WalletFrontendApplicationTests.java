package com.team.vendorfrontend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WalletFrontendApplicationTests {

	@Test
	void contextLoads() {
	}

}
