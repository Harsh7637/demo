package com.team.vendorfrontend.controller;

import com.team.vendorfrontend.model.User_DP;
import com.team.vendorfrontend.model.TransactionHistory_DP;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

@Controller
public class UsersController_DP {

    private final RestTemplate restTemplate = new RestTemplate();
    private static final String BACKEND_URL = "http://localhost:8484/api/user-transactions";

    /**
     * Display users list page
     */
    @GetMapping("/users_DP")
    public String getUsers(Model model) {
        try {
            // Fetch all users from backend
            String url = BACKEND_URL + "/users";
            ResponseEntity<User_DP[]> response = restTemplate.getForEntity(url, User_DP[].class);
            
            User_DP[] users = response.getBody();
            
            model.addAttribute("users", users != null ? users : new User_DP[0]);
            
        } catch (Exception e) {
            model.addAttribute("error", "Failed to fetch users: " + e.getMessage());
            model.addAttribute("users", new User_DP[0]);
        }
        
        return "users_DP";
    }

    /**
     * Display transaction history for a specific user
     */
    @GetMapping("/user_DP/{name}")
    public String getUserTransactions(@PathVariable String name, Model model) {
        try {
            // Fetch transactions by user name
            String url = BACKEND_URL + "/transactions/by-name?name=" + name;
            ResponseEntity<TransactionHistory_DP[]> response = 
                restTemplate.getForEntity(url, TransactionHistory_DP[].class);
            
            TransactionHistory_DP[] transactions = response.getBody();
            
            model.addAttribute("name", name);
            model.addAttribute("transactions", transactions != null ? transactions : new TransactionHistory_DP[0]);
            
        } catch (Exception e) {
            model.addAttribute("error", "Failed to fetch transactions: " + e.getMessage());
            model.addAttribute("name", name);
            model.addAttribute("transactions", new TransactionHistory_DP[0]);
        }
        
        return "user-transactions_DP";
    }
}