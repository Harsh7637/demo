package com.team.vendorfrontend.controller;

import com.team.vendorfrontend.model.User_JS;
import com.team.vendorfrontend.model.VirtualGoldHolding_JS;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;

@Controller
public class VirtualGoldController_JS {

    private final RestTemplate restTemplate = new RestTemplate();
    private static final String BACKEND_URL = "http://localhost:8484/api/user-gold";

    /**
     * Display users list page
     */
    @GetMapping("/users_JS")
    public String getUsers(Model model) {
        try {
            // Fetch all users from backend
            String url = BACKEND_URL + "/users";
            ResponseEntity<User_JS[]> response = restTemplate.getForEntity(url, User_JS[].class);
            
            User_JS[] users = response.getBody();
            
            model.addAttribute("users", users != null ? users : new User_JS[0]);
            
        } catch (Exception e) {
            model.addAttribute("error", "Failed to fetch users: " + e.getMessage());
            model.addAttribute("users", new User_JS[0]);
        }
        
        return "users_JS";
    }

    /**
     * Display virtual gold holdings for a specific user
     */
    @GetMapping("/user_JS/{name}")
    public String getUserHoldings(@PathVariable String name, Model model) {
        try {
            // Fetch holdings by user name
            String url = BACKEND_URL + "/holdings-by-name?name=" + name;
            ResponseEntity<VirtualGoldHolding_JS[]> response = 
                restTemplate.getForEntity(url, VirtualGoldHolding_JS[].class);
            
            VirtualGoldHolding_JS[] holdings = response.getBody();
            
            model.addAttribute("name", name);
            model.addAttribute("holdings", holdings != null ? holdings : new VirtualGoldHolding_JS[0]);
            
        } catch (Exception e) {
            model.addAttribute("error", "Failed to fetch holdings: " + e.getMessage());
            model.addAttribute("name", name);
            model.addAttribute("holdings", new VirtualGoldHolding_JS[0]);
        }
        
        return "virtualgoldholdings_JS";
    }
}