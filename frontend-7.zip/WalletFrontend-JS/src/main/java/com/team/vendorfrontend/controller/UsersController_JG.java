package com.team.vendorfrontend.controller;

import com.team.vendorfrontend.model.User_JG;
import com.team.vendorfrontend.model.Address_JG;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

@Controller
public class UsersController_JG {

    private final RestTemplate restTemplate = new RestTemplate();
    private static final String BACKEND_URL = "http://localhost:8484/api/jagat/users";

    /**
     * Display users list page
     */
    @GetMapping("/users_JG")
    public String getUsers(Model model) {
        try {
            // Fetch all users from backend
            ResponseEntity<List<User_JG>> response = restTemplate.exchange(
                BACKEND_URL,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<User_JG>>() {}
            );
            
            List<User_JG> users = response.getBody();
            
            if (users == null) {
                users = new ArrayList<>();
            }
            
            model.addAttribute("users", users);
            model.addAttribute("memberName", "Jagat");
            
        } catch (Exception e) {
            model.addAttribute("error", "Failed to fetch users: " + e.getMessage());
            model.addAttribute("users", new ArrayList<>());
        }
        
        return "users_JG";
    }

    /**
     * Display address details for a specific user
     */
    @GetMapping("/address_JG/{name}")
    public String getAddressByName(@PathVariable String name, Model model) {
        try {
            // Fetch address by user name
            String addressUrl = BACKEND_URL + "/address/by-name/" + name;
            ResponseEntity<Address_JG> response = restTemplate.exchange(
                addressUrl,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<Address_JG>() {}
            );
            
            Address_JG address = response.getBody();
            
            model.addAttribute("address", address);
            model.addAttribute("userName", name);
            
        } catch (Exception e) {
            model.addAttribute("error", "Failed to fetch address: " + e.getMessage());
            model.addAttribute("address", null);
            model.addAttribute("userName", name);
        }
        
        return "address_JG";
    }
}