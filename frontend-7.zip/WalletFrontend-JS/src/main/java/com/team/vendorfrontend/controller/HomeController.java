package com.team.vendorfrontend.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Arrays;
import java.util.List;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home(Model model) {
        List<TeamMember> teamMembers = Arrays.asList(
            new TeamMember("Harsh", "Backend API Integration & Vendor Management", "/vendors_HR"),
            new TeamMember("Abdullah", "User Management & Payment Processing", "/users_AB"),
            new TeamMember("Ganesh", "Branch Management & Vendor Analytics", "/vendors_GN"),
            new TeamMember("Jagat", "User & Address Management System", "/users_JG"),
            new TeamMember("Joshika", "Virtual Gold Holdings Management", "/users_JS"),
            new TeamMember("Deepika", "Transaction History & User Analytics", "/users_DP"),
            new TeamMember("Kiranmayee", "Physical Gold Transaction Management", "/users_KM")
            

        );

        model.addAttribute("teamMembers", teamMembers);
        model.addAttribute("projectName", "VendorFlow");
        model.addAttribute("projectTagline", "Next-Gen Vendor Management System");

        return "index";
    }

    // Inner class for team member data
    public static class TeamMember {
        private String name;
        private String contribution;
        private String link;

        public TeamMember(String name, String contribution, String link) {
            this.name = name;
            this.contribution = contribution;
            this.link = link;
        }

        public String getName() { return name; }
        public String getContribution() { return contribution; }
        public String getLink() { return link; }
    }
}